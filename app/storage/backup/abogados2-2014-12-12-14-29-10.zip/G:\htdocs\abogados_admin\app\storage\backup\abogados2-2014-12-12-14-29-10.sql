-- MySQL dump 10.13  Distrib 5.6.21, for Win32 (x86)
--
-- Host: localhost    Database: abogados
-- ------------------------------------------------------
-- Server version	5.6.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `abogados`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `abogados` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci */;

USE `abogados`;

--
-- Table structure for table `agendas`
--

DROP TABLE IF EXISTS `agendas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agendas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tipo_evento` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fecha` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `hora_inicio` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `hora_fin` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fecha_alarma` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `hora_alarma` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `observaciones` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agendas`
--

LOCK TABLES `agendas` WRITE;
/*!40000 ALTER TABLE `agendas` DISABLE KEYS */;
/*!40000 ALTER TABLE `agendas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backups`
--

DROP TABLE IF EXISTS `backups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tipo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backups`
--

LOCK TABLES `backups` WRITE;
/*!40000 ALTER TABLE `backups` DISABLE KEYS */;
/*!40000 ALTER TABLE `backups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clientes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `apellido` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dni` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `fecha_nacimiento` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `domicilio` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `localidad` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `telefono` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `celular` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES (1,'Martinez','Mariano','24655645','','mariano@abogados.com','jaskajskjksjakjaskj','askjajskajksajks','3814224578','154788878787','2014-12-09 16:57:10','2014-12-09 16:57:10'),(2,'Palmiero','Flavia','21156554','','flavia@abogados.com','ajsjasjkasjkajksa','ajksjakskjakjsak','4221575','381454544554','2014-12-09 16:57:37','2014-12-09 16:57:37');
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `escritos`
--

DROP TABLE IF EXISTS `escritos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `escritos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `expediente_id` int(10) unsigned NOT NULL,
  `titulo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cuerpo` longtext COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modelo_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `escritos_expediente_id_foreign` (`expediente_id`),
  KEY `escritos_modelo_id_foreign` (`modelo_id`),
  CONSTRAINT `escritos_expediente_id_foreign` FOREIGN KEY (`expediente_id`) REFERENCES `expedientes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `escritos_modelo_id_foreign` FOREIGN KEY (`modelo_id`) REFERENCES `modelos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `escritos`
--

LOCK TABLES `escritos` WRITE;
/*!40000 ALTER TABLE `escritos` DISABLE KEYS */;
INSERT INTO `escritos` VALUES (1,1,'Inicia Demanda','<p><strong><u>INICIA DEMANDA</u></strong></p>\r\n\r\n<p>Se&ntilde;or Juez:</p>\r\n\r\n<p><strong>&aacute;asj&amp;kajksk (lkaslkalksa)</strong>, constituyendo domicilio legal en la calle kakjsklajskl, a V.S. respetuosamente digo:</p>\r\n\r\n<p>1.<br />\r\nQue en nombre y representaci&oacute;n de <strong>kjljkaskjlaskj</strong> con domicilio real en la calle jhahjsajhs de jhjsauysuyas, conforme lo justifico con la fotocopia del poder general que adjunto acompa&ntilde;o, debidamente certificada y bajo juramento de ser fiel a su original vigente, vengo en tiempo y forma a promover @! por cobro de pesos contra asiuauisaiu domiciliado en iasiuasoi de hasja, solicitando que al dignarse V.S. dictar sentencia haga lugar a la misma y condene a la demandada al &iacute;ntegro pago del capital reclamado en el presente, de acuerdo a la liquidaci&oacute;n que se practica, actualizado a la fecha de su efectivo pago, con m&aacute;s sus intereses y las costas del juicio.</p>\r\n\r\n<p>2.<br />\r\n<strong>HECHOS</strong>.<br />\r\najhshjasjh</p>\r\n\r\n<p>3.<br />\r\n<strong>DERECHO</strong><br />\r\nFundo el derecho de mi parte en lo dispuesto por los arts. jkajsajksjka</p>\r\n\r\n<p>4.<br />\r\n<strong>PRUEBA</strong><br />\r\nOfrezco desde ya los siguientes medios de prueba, sin perjuicio de ampliarlos conforme a la facultad otorgada por el c&oacute;digo ritual, solicitando se ordene su oportuna producci&oacute;n.<br />\r\na<strong>) CONFESIONAL</strong>:<br />\r\nSe cite a la demandada a absolver posiciones a la audiencia que se designe al efecto, bajo apercibimiento de ley.<br />\r\nb<strong>) DOCUMENTAL:</strong><br />\r\nSe agregue la siguiente documentaci&oacute;n, reserv&aacute;ndose los respectivos originales en Secretar&iacute;a a cuyo efecto adjunto fotocopias para constancia de autos:<br />\r\nashasajks</p>\r\n\r\n<p><strong>5.<br />\r\nPETITORIO</strong><br />\r\nPor todo lo expuesto y consideraciones que suplir&aacute; la vasta ilustraci&oacute;n de V.S., solicito:<br />\r\na) Me tenga por presentado, por parte y por constituido el domicilio legal indicado a m&eacute;rito del poder que adjunto.<br />\r\nb) Se agregue la documentaci&oacute;n adjunta reserv&aacute;ndose los originales en Secretar&iacute;a.<br />\r\nc) Se confiera traslado de la demanda por el t&eacute;rmino y bajo apercibimiento de ley.<br />\r\nd) Se tenga presente la prueba ofrecida y la reserva de ampliarla.<br />\r\ne) Oportunamente, se digne V.S. dictar sentencia, haciendo lugar a la demanda y condenando a la contraria al &iacute;ntegro pago del capital reclamado, actualizado a la fecha de su efectivo pago, con m&aacute;s sus intereses y las costas del juicio.</p>\r\n\r\n<p>Proveer de conformidad,</p>\r\n\r\n<p>Ser&aacute; Justicia</p>\r\n\r\n<p>//jasjhajh</p>\r\n','2014-12-10 19:34:37','2014-12-10 19:34:37',1);
/*!40000 ALTER TABLE `escritos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `escritos_importaciones`
--

DROP TABLE IF EXISTS `escritos_importaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `escritos_importaciones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `expediente_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `nombre_archivo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `escritos_importaciones_expediente_id_foreign` (`expediente_id`),
  CONSTRAINT `escritos_importaciones_expediente_id_foreign` FOREIGN KEY (`expediente_id`) REFERENCES `expedientes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `escritos_importaciones`
--

LOCK TABLES `escritos_importaciones` WRITE;
/*!40000 ALTER TABLE `escritos_importaciones` DISABLE KEYS */;
INSERT INTO `escritos_importaciones` VALUES (1,1,'2014-12-12 16:45:04','2014-12-12 16:45:04','apela sentencia.RTF'),(2,1,'2014-12-12 17:05:07','2014-12-12 17:05:07','daños y perjuicios.RTF');
/*!40000 ALTER TABLE `escritos_importaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expedientes`
--

DROP TABLE IF EXISTS `expedientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expedientes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cliente_id` int(10) unsigned NOT NULL,
  `numero` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `caratula` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `juzgado` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fecha_inicio` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fecha_presentacion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fecha_finalizacion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tipo_proceso` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pagos` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `expedientes_cliente_id_foreign` (`cliente_id`),
  CONSTRAINT `expedientes_cliente_id_foreign` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expedientes`
--

LOCK TABLES `expedientes` WRITE;
/*!40000 ALTER TABLE `expedientes` DISABLE KEYS */;
INSERT INTO `expedientes` VALUES (1,2,'5454545454','Desalojo Familia Lopez','Juzgado de Martinez Bs As','Iniciado','2014-12-09','2014-12-24','','Comercial Común','','2014-12-09 16:59:09','2014-12-09 16:59:09'),(2,1,'','Juicio por Violacion Caceres - Roldan','Juzgado Caseros','Iniciado','2014-12-02','2014-12-23','','Laboral','','2014-12-09 17:01:29','2014-12-09 17:01:29');
/*!40000 ALTER TABLE `expedientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES ('2014_10_16_030431_crear_tabla_usuarios',1),('2014_10_22_024314_crear_tabla_clientes',1),('2014_10_25_191043_create_password_reminders_table',1),('2014_10_31_214601_crear_tabla_agendas',1),('2014_11_04_045754_crear_tabla_expedientes',1),('2014_11_05_153335_crear_tabla_escritos',1),('2014_11_06_033415_crear_tabla_modelos',1),('2014_11_06_051828_crear_tabla_pagos',1),('2014_11_11_044253_agregar_titular_id_to_usuarios',1),('2014_11_11_045824_agregar_parentesco_to_usuarios',1),('2014_11_12_051000_crear_tabla_backups',1),('2014_11_30_183702_agregar_est_civil_localidad_legajo_sexo_tel_cel_prof_ingreso_to_usuarios',2),('2014_12_03_064823_AgregarDiscapacidadToUsuarios',2),('2014_12_04_110448_eliminar_texto_text_from_modelos',2),('2014_12_04_111502_agregar_texto_longtext_to_modelos',2),('2014_12_04_151941_modificar_expediente_id_en_pagos',2),('2014_12_04_211319_agregar_modelo_id_en_escritos',2),('2014_12_04_213357_eliminar_estado_y_provincia_en_agendas_clientes_escritos_modelos_pagos',2),('2014_12_05_010240_crear_tabla_modelos_codigos',2),('2014_12_05_043420_modificar_cuerpo_eliminar_descripcion_en_escritos',2),('2014_12_05_092020_crear_tabla_modelos_codigos_relacionados',2),('2014_12_08_051652_craar_tabla_modelos_procesos',2),('2014_12_08_051809_craar_tabla_modelos_procesos_relacionados',2),('2014_12_08_060916_eliminar_columna_tipo_proceso_de_modelos',2),('2014_12_09_035440_crear_tabla_escritos_importaciones',2),('2014_12_10_045034_modificar_columna_monto_en_pagos',3),('2014_12_12_045053_eliminar_titulo_modificar_ruta_archivo_en_escritos_importaciones',4);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modelos`
--

DROP TABLE IF EXISTS `modelos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modelos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `texto` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modelos`
--

LOCK TABLES `modelos` WRITE;
/*!40000 ALTER TABLE `modelos` DISABLE KEYS */;
INSERT INTO `modelos` VALUES (1,'Inicia Demanda','2014-12-05 03:42:52','2014-12-05 03:52:18','<p><strong><u>INICIA DEMANDA</u></strong></p>\r\n\r\n<p>Se&ntilde;or Juez:</p>\r\n\r\n<p><strong>@004</strong>, constituyendo domicilio legal en la calle @006, a V.S. respetuosamente digo:</p>\r\n\r\n<p>1.<br />\r\nQue en nombre y representaci&oacute;n de <strong>#@023</strong> con domicilio real en la calle @031 de @032#, conforme lo justifico con la fotocopia del poder general que adjunto acompa&ntilde;o, debidamente certificada y bajo juramento de ser fiel a su original vigente, vengo en tiempo y forma a promover @! por cobro de pesos contra #@040 domiciliado en @048 de @049#, solicitando que al dignarse V.S. dictar sentencia haga lugar a la misma y condene a la demandada al &iacute;ntegro pago del capital reclamado en el presente, de acuerdo a la liquidaci&oacute;n que se practica, actualizado a la fecha de su efectivo pago, con m&aacute;s sus intereses y las costas del juicio.</p>\r\n\r\n<p>2.<br />\r\n<strong>HECHOS</strong>.<br />\r\n@000Hechos@</p>\r\n\r\n<p>3.<br />\r\n<strong>DERECHO</strong><br />\r\nFundo el derecho de mi parte en lo dispuesto por los arts. @000Fundo el derecho en los arts ...@</p>\r\n\r\n<p>4.<br />\r\n<strong>PRUEBA</strong><br />\r\nOfrezco desde ya los siguientes medios de prueba, sin perjuicio de ampliarlos conforme a la facultad otorgada por el c&oacute;digo ritual, solicitando se ordene su oportuna producci&oacute;n.<br />\r\na<strong>) CONFESIONAL</strong>:<br />\r\nSe cite a la demandada a absolver posiciones a la audiencia que se designe al efecto, bajo apercibimiento de ley.<br />\r\nb<strong>) DOCUMENTAL:</strong><br />\r\nSe agregue la siguiente documentaci&oacute;n, reserv&aacute;ndose los respectivos originales en Secretar&iacute;a a cuyo efecto adjunto fotocopias para constancia de autos:<br />\r\n@000Detalle la prueba documental@</p>\r\n\r\n<p><strong>5.<br />\r\nPETITORIO</strong><br />\r\nPor todo lo expuesto y consideraciones que suplir&aacute; la vasta ilustraci&oacute;n de V.S., solicito:<br />\r\na) Me tenga por presentado, por parte y por constituido el domicilio legal indicado a m&eacute;rito del poder que adjunto.<br />\r\nb) Se agregue la documentaci&oacute;n adjunta reserv&aacute;ndose los originales en Secretar&iacute;a.<br />\r\nc) Se confiera traslado de la demanda por el t&eacute;rmino y bajo apercibimiento de ley.<br />\r\nd) Se tenga presente la prueba ofrecida y la reserva de ampliarla.<br />\r\ne) Oportunamente, se digne V.S. dictar sentencia, haciendo lugar a la demanda y condenando a la contraria al &iacute;ntegro pago del capital reclamado, actualizado a la fecha de su efectivo pago, con m&aacute;s sus intereses y las costas del juicio.</p>\r\n\r\n<p>Proveer de conformidad,</p>\r\n\r\n<p>Ser&aacute; Justicia</p>\r\n\r\n<p>//@000Colocar segun corresponda|demanda Sumaria|demanda Ordinaria@</p>\r\n'),(2,'Contesta Demanda','2014-12-05 03:45:11','2014-12-08 00:55:46','<p><strong><u>CONTESTA DEMANDA</u></strong>.</p>\r\n\r\n<p>Se&ntilde;or Juez:</p>\r\n\r\n<p><strong>@004</strong> constituyendo domicilio legal en la calle @006 en autos caratulados: @016 <strong>&quot;@002&quot;</strong>, a V.S. me presento y digo:</p>\r\n\r\n<p>1.<br />\r\nQue en nombre y representaci&oacute;n de #@023 con domicilio real en la calle @031 de @032, conforme lo justifico con la fotocopia del poder general que adjunto acompa&ntilde;o, debidamente certificada y bajo juramento de ser fiel a su original que se encuentra en vigencia, vengo en tiempo y forma a tomar intervenci&oacute;n en autos, solicitando se me tenga por presentado, por parte y por constituido el domicilio legal indicado.</p>\r\n\r\n<p>2.<br />\r\nEn el car&aacute;cter invocado y en cumplimiento de expresas instrucciones recibidas de mi mandante, paso a contestar la demanda promovida en su contra, solicitando que al dignarse V.S. dictar sentencia, rechace la misma en todas sus partes. Con costas a la accionante.</p>\r\n\r\n<p>3.<br />\r\nEn cumplimiento de un imperativo legal, niego todos y cada uno de los hechos expuestos en el escrito de inicio en cuanto no fueren objeto de especial reconocimiento en este de responde.<br />\r\nAsimismo niego la autenticidad de toda documentaci&oacute;n agregada por la actora en cuanto no fuere expresamente reconocida por mi parte.</p>\r\n\r\n<p>3.<br />\r\n@000Comenzar pto. 4 despues de negativa general@</p>\r\n\r\n<p>Proveer de conformidad,</p>\r\n\r\n<p>Ser&aacute; Justicia.</p>\r\n\r\n<p>J:@009 / S:@010</p>\r\n'),(4,'Inicia Demanda Daños y Perjuicios','2014-12-05 03:51:23','2014-12-05 03:51:23','<p><strong><u>INICIA DEMANDA DA&Ntilde;OS Y PERJUICIOS.</u></strong></p>\r\n\r\n<p>Se&ntilde;or Juez:</p>\r\n\r\n<p><strong>@004</strong>, constituyendo domicilio legal en la calle @006, a V.S. respetuosamente digo:</p>\r\n\r\n<p><strong>1</strong>. <strong>PERSONERIA</strong><br />\r\nQue vengo en nombre y representaci&oacute;n de #@023 con domicilio real en la calle @031 de @032#, conforme lo justifico con la fotocopia del poder general que adjunto acompa&ntilde;o, debidamente certificada y bajo juramento de ser fiel a su original vigente.</p>\r\n\r\n<p><strong>2</strong>. <strong>OBJETO</strong><br />\r\nEn tal car&aacute;cter, y habiendo recibido precisas instrucciones de mi poderdante, vengo por el presente a iniciar iniciar acci&oacute;n judicial, contra #@040, con domicilio en la calle @048, @049#, por da&ntilde;os y perjuicios por la suma de $ @018 (@101) con m&aacute;s sus correspondientes intereses y costas.</p>\r\n\r\n<p><strong>3</strong>. <strong>HECHOS</strong><br />\r\n@000Narrar los hechos@</p>\r\n\r\n<p><strong>4.</strong> <strong>DA&Ntilde;OS</strong><br />\r\n@000Detallar los danos@</p>\r\n\r\n<p><strong>5. PRIVACION DEL USO</strong><br />\r\nMi poderdante se vio privado del uso por el lapso de @000Lapso por el cual fue privado del uso@. Estimo el monto del perjuicio ocasionado en la suma de @000Monto en Nro y letras por la privacion de uso@.</p>\r\n\r\n<p><strong>6</strong>. <strong>DERECHO</strong><br />\r\nFundo la acci&oacute;n en los arts. @000Arts. en los que fundamenta la accion@</p>\r\n\r\n<p><strong>7.</strong> <strong>OFRECIMIENTO DE PRUEBA</strong><br />\r\nQue en apoyo del derecho que asiste a mi parte vengo a ofrecer la siguiente prueba:<br />\r\na) <strong>DOCUMENTAL:</strong><br />\r\n@000Detalle Prueba documental@<br />\r\nb) <strong>CONFESIONAL:</strong><br />\r\nSe cite al demandado a absolver posiciones a la audiencia que V.S. fijar&aacute; al efecto y bajo apercibimiento de Ley.<br />\r\nc) <strong>PERICIAL:</strong><br />\r\n@000Detalle Prueba pericial@<br />\r\nd) <strong>INFORMATIVA:</strong><br />\r\nSe libren oficios a los siguientes: @000Se libren oficios a ...@</p>\r\n\r\n<p><strong>8</strong>. <strong>PETITORIO:</strong><br />\r\nEn m&eacute;rito de lo expuesto a V.S. solicito:<br />\r\na) Me tenga por presentado, por parte y por constituido el domicilio legal indicado a m&eacute;rito del poder que adjunto.<br />\r\nb) Se corra traslado de la demanda por el t&eacute;rmino y bajo apercibimiento de ley.<br />\r\nc) Se tenga presente la prueba ofrecida.<br />\r\nd) Se condene al demandado al &iacute;ntegro pago de lo reclamado o lo que mas o en menos resulte de la prueba a producirse con costas.</p>\r\n\r\n<p>Proveer de conformidad,</p>\r\n\r\n<p>Ser&aacute; Justicia.</p>\r\n'),(6,'Acompaña Comprobantes. Pide se dicte declaratoria de herederos','2014-12-05 03:55:42','2014-12-05 03:55:42','<p><strong><u>ACOMPA&Ntilde;A COMPROBANTES. PIDE SE DICTE DECLARATORIA DE HEREDEROS</u></strong><strong>.</strong></p>\r\n\r\n<p>Se&ntilde;or Juez:</p>\r\n\r\n<p><strong>@004</strong> en mi car&aacute;cter de Letrado @005 de la parte @025, con domicilio legal constituido en la calle @006, en los autos caratulados <strong>&quot;@002&quot;</strong> (Expte. N&ordm; @016), a V.S. digo:</p>\r\n\r\n<p>1.<br />\r\nQue vengo a adjuntar comprobante de publicaci&oacute;n de edictos as&iacute; como de pago de los mismos.</p>\r\n\r\n<p>2.<br />\r\nTeniendo en cuenta lo expuesto y el estado de autos, solicito que previa certificaci&oacute;n a practicar por el Se&ntilde;or Actuario, sobre el vencimiento de la publicaci&oacute;n de edictos as&iacute; como de los eventuales herederos y acreedores que se hubieren presentado, se dicte declaratoria de herederos conforme a derecho.</p>\r\n\r\n<p>Proveer de conformidad,</p>\r\n\r\n<p>Ser&aacute; Justicia.</p>\r\n\r\n<p>J: @009 / S:@010</p>\r\n'),(7,'Demanda Por Adopción','2014-12-05 03:57:53','2014-12-08 01:43:45','<p><strong><u>PETICIONAN POR ADOPCION</u></strong></p>\r\n\r\n<p>Sr. Juez:</p>\r\n\r\n<p><strong>@004</strong>, constituyendo domicilio legal en la calle @006, a V.S. respetuosamente digo:</p>\r\n\r\n<p><strong>1</strong>. <strong>PERSONERIA</strong><br />\r\nQue vengo en nombre y representaci&oacute;n de #@023 con domicilio real en la calle @031 de @032#, conforme lo justifico con la fotocopia del poder general que adjunto acompa&ntilde;o, debidamente certificada y bajo juramento de ser fiel a su original vigente.</p>\r\n\r\n<p><strong>2</strong>. <strong>OBJETO</strong><br />\r\nQue por las consideraciones de hecho y de derecho que se expondr&aacute;n y ampar&aacute;ndose en la ley de adopci&oacute;n, venimos en tiempo y forma ante S.S. para que nos conceda la adopci&oacute;n del menor #@041.</p>\r\n\r\n<p><strong>3</strong>.<br />\r\nQue el menor es hijo de @000Nombre de los padres del menor@, el que es nacido el @000Fecha de nacimiento del menor@ en @000Lugar de nacimiento@.</p>\r\n\r\n<p><strong>4.</strong><br />\r\nDicho menor se encuentra bajo nuestra guarda, por concesion del Consejo Nacional del Menor, desde @000Fecha desde la cual se tiene al menor bajo guarda@, como lo probaremos, de ello a la fecha de presentaci&oacute;n de &eacute;ste pedido han pasado @000Anos de guarda@ a&ntilde;os.<br />\r\nDem&aacute;s est&aacute; manifestar a V.S. que a #@041 se le ha facilitado educaci&oacute;n, estudios, atenci&oacute;n m&eacute;dica. Adem&aacute;s mi esposa es ama de casa por lo cual est&aacute; permanentemente en la casa. Estamos casados desde el @000Fecha de casamiento@ como lo comprobaremos. No tenemos m&aacute;s elogios para el menor, quien nos demuestra un cari&ntilde;o que excede a toda ponderaci&oacute;n.</p>\r\n\r\n<p><strong>5.</strong><br />\r\nQue la solicitud que realizaremos a V.S. es de nuestra entera necesidad, ya que el menor es merecedor de nuestra protecci&oacute;n con derechos para &eacute;l, presentes y futuros dada nuestra posici&oacute;n econ&oacute;mica, solvente de todo punto de vista, por otra parte no olvidamos que #@041 se ha encontrado sin el cari&ntilde;o de sus padres, hasta que entr&oacute; en nuestro hogar en el que creci&oacute; fuerte y espiritualmente noble.</p>\r\n\r\n<p><strong>6.</strong><br />\r\nManifiesto a V.S. que nuestras entradas superan los $ @000Entrada mensual de los conyuges@ mensualmente.</p>\r\n\r\n<p><strong>7. PRUEBAS</strong><br />\r\na) Partida de matrimonio;<br />\r\nb) Certificado de buena conducta;<br />\r\nc) Certificado de trabajo;<br />\r\nd) Partida de nacimiento del menor que solicitamos en adopci&oacute;n;<br />\r\ne) Certificado otorgado por el Consejo del Menor.<br />\r\nf) Testimonial: Nombre, profesi&oacute;n, domicilio (art. 429 C.P.C.C.; y testimonial de tres testigos.</p>\r\n\r\n<p><strong>8. PETITORIO<br />\r\na</strong>) Me tenga por presentado, por parte y por constituido el domicilio legal indicado a m&eacute;rito del poder que adjunto.<br />\r\nb) Se agregue la documentaci&oacute;n acompa&ntilde;ada.<br />\r\nc) Se otorgue la adopci&oacute;n que solicitamos, previa vista al Asesor de Menores.</p>\r\n\r\n<p>Proveer de conformidad,</p>\r\n\r\n<p>Ser&aacute; Justicia.</p>\r\n'),(8,'Demanda Por Cobro de Alimentos','2014-12-05 03:59:37','2014-12-05 03:59:37','<p><strong><u>DEMANDA POR COBRO DE ALIMENTOS</u></strong></p>\r\n\r\n<p>Se&ntilde;or Juez:</p>\r\n\r\n<p><strong>@004</strong>, constituyendo domicilio legal en la calle @006, a V.S. respetuosamente digo:</p>\r\n\r\n<p><strong>1. PERSONERIA</strong><br />\r\nQue vengo en nombre y representaci&oacute;n de <strong>#@023</strong> con domicilio real en la calle @031 de @032#, conforme lo justifico con la fotocopia del poder general que adjunto acompa&ntilde;o, debidamente certificada y bajo juramento de ser fiel a su original vigente. La presente acci&oacute;n es promovida por el derecho de mi mandante de ser esposa leg&iacute;tima del accionado y en ejercicio de la representaci&oacute;n que la Patria Potestad le confiere sobre la persona de @000Nombre de el o los hijos@, @!, todo lo cual se acredita con las partidas de matrimonio y nacimiento que se acompa&ntilde;an.</p>\r\n\r\n<p><strong>2. OBJETO</strong><br />\r\nEn el referido car&aacute;cter vengo en tiempo y forma a promover demanda con el objeto de que V.S. fije judicialmente la cuota que el demandado deber&aacute; pasar a mi mandante en concepto de alimentos desde el momento de interposici&oacute;n de la acci&oacute;n que por este acto promuevo.<br />\r\nLa pretensi&oacute;n se dirige contra <strong>#@040</strong>, con domicilio en la calle @048, @049#</p>\r\n\r\n<p><strong>3. HECHOS</strong><br />\r\n@000Narrar los hechos@</p>\r\n\r\n<p><strong>4. FIJACION DE ALIMENTOS PROVISORIOS</strong><br />\r\nExistiendo verosimilitud del derecho alimentario que asiste a mi mandante, el que se acredita con las partidas acompa&ntilde;adas justificantes del v&iacute;nculo con el demandado, por un lado, y por otro, la necesidad impostergable de atender la subsistencia, la que hoy por hoy es materialmente imposible de satisfacer por carecer de recursos propios, solicito de S.S. fije como cuota provisoria a pagarse por el demandado durante el proceso y en el plazo que se determine, la suma de pesos @000Monto en letras de cuota provisoria de alimentos@ ($ @000Monto en numeros@).</p>\r\n\r\n<p><strong>5. MEDIDAS CAUTELARES</strong><br />\r\n@000Detallar medidas cautelares que se solicitan@</p>\r\n\r\n<p><strong>6. DERECHO</strong><br />\r\nFundo el derecho que me asiste en los arts. 198, 367, 372, 375 del C&oacute;digo Civil y 635 y ss. del C&oacute;digo Procesal de aplicaci&oacute;n.</p>\r\n\r\n<p><strong>7. PRUEBAS</strong><br />\r\na) CONFESIONAL Se citar&aacute; al demandado a absolver posiciones a tenor del pliego que se acompa&ntilde;a y bajo apercibimiento de ley<br />\r\nb) DOCUMENTAL: Partida de matrimonio, partida de nacimiento, @000Prueba documental: partida matrim. y nacim, y ...@<br />\r\nc) TESTIMONIAL: Se ordene la citaci&oacute;n de las siguientes personas que declarar&aacute;n como testigos en la audiencia que se se&ntilde;ale:<br />\r\n#@066, @111, @112, con domicilio en @085#<br />\r\nd) INFORMATIVA: Se ordene librar oficio a:<br />\r\n@000Se libren oficios a ...@</p>\r\n\r\n<p><strong>8. PETITORIO:</strong><br />\r\nPor todo lo expuesto solicito:<br />\r\na) Me tenga por presentado, por parte y por constituido el domicilio legal indicado a m&eacute;rito del poder que adjunto.<br />\r\nb) Se convoque a la audiencia prevista por el art. 636 de la ley ritual.<br />\r\nc) Fije Vs. los alimentos provisorios solicitados<br />\r\nd) Por ofrecida la prueba.<br />\r\ne) Opotunamente haga lugar a la demanda en todas sus partes con costas al demandado.</p>\r\n\r\n<p>Proveer de conformidad,</p>\r\n\r\n<p>Ser&aacute; Justicia.<br />\r\n//@000Elegir entre:|hijo legitimo|hijos legitimos@</p>\r\n'),(10,'Pide Apertura a Prueba','2014-12-07 23:24:01','2014-12-07 23:24:01','<p><strong><u>PIDE APERTURA A PRUEBA</u></strong></p>\r\n\r\n<p>Se&ntilde;or Juez:</p>\r\n\r\n<p><strong>@004</strong>, en mi car&aacute;cter de Letrado @005 de la parte @025, y por mi propio derecho, con domicilio legal constituido en la calle @006, en los autos caratulados <strong>&quot;@002&quot;</strong> (Expte. N&ordm; @016), a V.S. me presento y digo:</p>\r\n\r\n<p>Que atento al estado de autos, solicito la apertura del juicio a prueba.</p>\r\n\r\n<p>Proveer de conformidad,</p>\r\n\r\n<p>Ser&aacute; justicia.</p>\r\n\r\n<p>J:@009 / S:@010</p>\r\n'),(11,'Apela Sentencia','2014-12-07 23:24:46','2014-12-07 23:24:46','<p><strong><u>INTERPONE RECURSO DE APELACION CONTRA SENTENCIA</u></strong></p>\r\n\r\n<p>Se&ntilde;or Juez:</p>\r\n\r\n<p><strong>#@023</strong>, por derecho propio, manteniendo el domicilio legal constituido junto al Letrado que me patrocina, Doctor @004, en calle @006, en autos caratulados: <strong>&quot;@002&quot;</strong> (Expte. N&ordm; @016), a V.S. digo:</p>\r\n\r\n<p>1. En tiempo y forma vengo a interponer recurso de apelaci&oacute;n contra la sentencia dictada en autos de fojas @000Indique fs. del fallo@ por causar gravamen irreparable.</p>\r\n\r\n<p>2. Solicitando se conceda el mismo libremente y oportunamente se eleven los autos a la Excma. C&aacute;mara de Apelaciones en la forma de estilo.</p>\r\n\r\n<p>Proveer de conformidad,</p>\r\n\r\n<p>Ser&aacute; Justicia.</p>\r\n\r\n<p>J:@009 / S:@010</p>\r\n'),(12,'Contesta Demanda Laboral','2014-12-07 23:28:07','2014-12-07 23:28:07','<p><strong><u>CONTESTA DEMANDA. OFRECE PRUEBA. PIDE AUDIENCIA. PLANTEA INCONSTITUCIONALIDAD.</u></strong></p>\r\n\r\n<p>Se&ntilde;or Juez:</p>\r\n\r\n<p><strong>@004</strong>, en mi car&aacute;cter de Letrado @005 de la parte #@025#, con domicilio legal constituido en la calle @006, en los autos caratulados: <strong>&quot;@002&quot;</strong>, (Expte. N&ordm; @016), a V.S. digo:</p>\r\n\r\n<p><strong>1. EXORDIO:</strong><br />\r\nSeg&uacute;n lo acredito con la copia simple del testimonio de escritura de otorgamiento de poder general judicial, sobre el que declaro bajo juramento ser fiel de su original y encontrarse vigente, he sido institu&iacute;do mandatario de <strong><u>#@023</u></strong>, @157, @030, domiciliado en @031 de la localidad de @032#.</p>\r\n\r\n<p><strong>2. OBJETO:</strong><br />\r\nEn el expresado car&aacute;cter y cumpliendo expresas instrucciones al respecto recibidas vengo en tiempo y forma a contestar el traslado que a mi mandatario se le corriera de la demanda, solicitando desde ya el rechazo de la pretensi&oacute;n de la actora en todas sus partes, en raz&oacute;n de las consideraciones de hecho y de derecho a continuaci&oacute;n expuestas.</p>\r\n\r\n<p><strong>3. HECHOS:</strong><br />\r\nNiego todos y cada uno de los hechos expuestos en la demanda que no sean materia de expreso reconocimiento en el presente. @020.</p>\r\n\r\n<p><strong>4. SUMAS RECLAMADAS:</strong><br />\r\nSin perjuicio de lo manifestado hasta aqu&iacute; en relaci&oacute;n con la improcedencia de los reclamos, impugno la liquidaci&oacute;n practicada en el escrito de iniciaci&oacute;n, y para el hipot&eacute;tico caso -que desde ya descarto de prosperar la demanda, deben ser exclu&iacute;dos los improcedentes rubros que la componen y reducirse los otros a sus justos l&iacute;mites de acuerdo con el resultado de la prueba a producirse.</p>\r\n\r\n<p><strong>5. DERECHO:</strong><br />\r\n@000Fundar en derecho@.</p>\r\n\r\n<p><strong>6. PRUEBA:</strong><br />\r\na) <strong>CONFESIONAL:</strong><br />\r\nSe cite a la actora para que absuelva posiciones a tenor del pliego adjunto.<br />\r\nb) <strong>DOCUMENTAL:</strong><br />\r\n@000Prueba documental@.<br />\r\nc) <strong>TESTIMONIAL:</strong><br />\r\n#@066, @111, domiciliado en @067#. Solicito que estos testigos sean citados por el Tribunal para ser examinados en la vista de causa.<br />\r\nd) <strong>INFORMATIVA:</strong><br />\r\nSe librar&aacute;n los siguientes oficios: #@076, a fin de que informe sobre @078 @083#.<br />\r\ne) <strong>PERICIAL CONTABLE:</strong><br />\r\nSe designar&aacute; perito contador &uacute;nico quien examinando los libros y papeles comerciales y laborales de mi representada, se expedir&aacute; sobre los siguientes puntos de pericia: @000Puntos de Pericia Contable@.<br />\r\nf) <strong>PERICIAL CALIGRAFICA:</strong><br />\r\n@000Detalle Pericial Caligrafica@.</p>\r\n\r\n<p><strong>7. AUDIENCIA DE CONCILIACION:</strong><br />\r\nConforme lo dispuesto por el art. 25 de la ley 7718 y a fin de intentar una conciliaci&oacute;n, corresponde y solicito se se&ntilde;ale la audiencia que prescribe la citada norma ritual.</p>\r\n\r\n<p><strong>8. OPOSICION RESPECTO DE AMPLIACIONES DE PRUEBA:</strong><br />\r\nEn el proceso laboral, la litis se integra con los escritos de demanda y su contestaci&oacute;n, confiri&eacute;ndose el segundo traslado -previsto por el art. 29 de la ley 7718-, al s&oacute;lo efecto que el actor ampl&iacute;e su prueba respecto de nuevos hechos alegados en la contestaci&oacute;n de demanda. No habi&eacute;ndose introducido ellos, toda vez que lo expresado y argumentado en el presente responde se refiere a hechos ocurridos y conocidos por la actora antes de la interposici&oacute;n de la demanda, me opongo expresamente a que el accionante ofrezca y/o ampl&iacute;e su prueba o que efect&uacute;e nuevas alegaciones respecto de los hechos y el derecho. De lo contrario se violar&iacute;a el principio de preclusi&oacute;n y la igualdad procesal que hace al derecho de defensa en juicio, por lo que hago expresa reserva del caso federal previsto por el art.14 de la ley 48.</p>\r\n\r\n<p><strong>9. PLANTEA INCONSTITUCIONALIDAD:</strong><br />\r\nDesde ya planteo la inconstitucionalidad de los arts. 180, 181, 184, 187, 189, 190, 194, 196, 199, 200, 204, 205, 207, 208, 212, 219, 222, 229, 236 de la ley 10.620, por resultar violatorios de los arts. 16, 17 y 18 del la Constituci&oacute;n Nacional.</p>\r\n\r\n<p><strong>10. PLANTEA CASO FEDERAL:</strong><br />\r\nA todo evento, y para el supuesto que descarto de no hacerse lugar al planteo de inconstitucionalidad de la ley 10.620 efectuado en el cap&iacute;tulo precedente, y/o para el caso de un decisorio contrario a esta parte sobre las pautas de la referida norma legal, formulo la reserva del caso federal, por pretensa violaci&oacute;n de la garant&iacute;a de intangibilidad de la defensa en juicio (art. 18 de la C.N.) y en los t&eacute;rminos de los arts. 14 y 15 de la ley 48.</p>\r\n\r\n<p><strong>11. PETITORIO:</strong><br />\r\nPor todo lo expuesto, corresponde y solicito:<br />\r\na) Se me tenga por presentado y por parte en el car&aacute;cter invocado y con el domicilio procesal constituido.<br />\r\nb) Se tenga por evacuado en tiempo y forma el traslado de la demanda conferido y por ofrecida la prueba.<br />\r\nc) Se se&ntilde;ale la audiencia de conciliaci&oacute;n solicitada en el cap&iacute;tulo V del presente responde.<br />\r\nd) Se tenga presente que autorizo a mi letrado patrocinante y a @000Personas autorizadas@, para que en forma indistinta retiren del Tribunal c&eacute;dulas, oficios, mandamientos y corran con sus diligenciamientos; como as&iacute; tambi&eacute;n para que practiquen los desgloses que se autoricen.<br />\r\ne) En la estaci&oacute;n oportuna del juicio, se rechace la demanda con costas.</p>\r\n\r\n<p>Proveer de conformidad,</p>\r\n\r\n<p>Ser&aacute; Justicia</p>\r\n\r\n<p>J:@009 / S:@010</p>\r\n'),(13,'Demanda Por Accidente de Trabajo','2014-12-07 23:32:46','2014-12-07 23:32:46','<p><strong><u>INICIA DEMANDA POR ACCIDENTE DE TRABAJO</u></strong></p>\r\n\r\n<p>Se&ntilde;or Juez:</p>\r\n\r\n<p><strong>@004</strong>, constituyendo domicilio legal en la calle @006, a V.S. respetuosamente digo:</p>\r\n\r\n<p>1. <strong>REPRESENTACION:</strong><br />\r\nQue vengo a actuar en nombre y representaci&oacute;n de <strong>#@023</strong>, con domicilio real en la calle @031 de @032, de nacionalidad @157, nacido el d&iacute;a @029, @105, de estado civil @027, y comprobando su identidad con @030#, conforme lo justifico con la fotocopia del poder general que adjunto acompa&ntilde;o, debidamente certificada y bajo juramento de ser fiel a su original vigente.</p>\r\n\r\n<p>2. <strong>OBJETO:</strong><br />\r\nQue en cumplimiento de expresas instrucciones de mi representada, vengo a iniciar demanda por cobro de la indemnizaci&oacute;n especial tarifada prevista en la ley 24028 de accidentes de trabajo, contra #@040, domiciliado en la calle @048 de @049#, por las consideraciones de hecho y derecho que a continuaci&oacute;n se exponen.</p>\r\n\r\n<p>3. <strong>HECHOS Y CONTRATO DE TRABAJO:</strong><br />\r\n@000Narrar hechos y contrato de trabajo@</p>\r\n\r\n<p>4. <strong>PRUEBA:</strong><br />\r\nOfrezco desde ya los siguientes medios de prueba, sin perjuicio de ampliarlos conforme a la facultad otorgada por el c&oacute;digo ritual, solicitando se ordene su oportuna producci&oacute;n:<br />\r\na) <strong>CONFESIONAL Y DE RECONOCIMIENTO DE DOCUMENTOS:</strong><br />\r\nSe adjunta pliego de posiciones bajo sobre cerrado, a cuyo tenor deber&aacute; deponer la @042 bajo apercibimiento de ley.<br />\r\nb) <strong>INTIMACION A PRESENTAR EL ORIGINAL DE LA FICHA CLINICA DEL SERVICIO MEDICO DE LA DEMANDADA CORRESPONDIENTE AL</strong> <strong>ACTOR</strong>:<br />\r\nLa demandada debe llevar en su servicio m&eacute;dico una ficha cl&iacute;nica de atenci&oacute;n de la actora, con constancia suscripta por el mismo de la informaci&oacute;n de los m&eacute;dicos sobre las circunstancias de constataci&oacute;n de la alteraci&oacute;n de su salud.<br />\r\nPor ello se pide a V.S. que intime a la demandada acompa&ntilde;e el original de dicha ficha cl&iacute;nica, conforme al art. 387 del C.P.C.C., todo bajo el apercibimiento legal de la presunci&oacute;n que determina el art. 55 de la ley 21.297 y el art. 388 del C.P.C.C.<br />\r\nc) <strong>TESTIMONIAL:</strong><br />\r\nSe ofrece la declaraci&oacute;n testimonial de las siguientes personas:<br />\r\n#@066, con domicilio en la calle @067#.<br />\r\nd) <strong>PERICIAL MEDICA:</strong><br />\r\nSe deber&aacute; designar perito m&eacute;dico de oficio, para que informe sobre los siguientes puntos:<br />\r\nd.1) Sobre las enfermedades que padece el actor, denunciadas<br />\r\nesta demanda. Informar&aacute; detalladamente, refiri&eacute;ndolas en especial a los efectos sobre su capacidad laboral;<br />\r\nd.2) Deber&aacute; informar las causas y concausas laborales de esas enfermedades;<br />\r\nd.3) Deber&aacute; determinar el grado de incapacidad laboral que le crean al demandante sobre la total obrera;<br />\r\nd.4) Informar&aacute; si las enfermedades que padece el actor son de evoluci&oacute;n progresiva, y de ser as&iacute;, en que estado de evoluci&oacute;n se encuentran;<br />\r\nd.5) Transcribir&aacute; textualmente la ficha cl&iacute;nica correspondiente al actor, del servicio m&eacute;dico de la demandada;<br />\r\nd.6) Interpretar&aacute; sus anotaciones con referencia a su dictamen y aclarar&aacute; los t&eacute;rminos m&eacute;dicos para mejor entendimiento de V.S. y las partes;<br />\r\nd.7) Informar&aacute; si en esa ficha se encuentran notificados los diagn&oacute;sticos al actor, con constancia firmada por &eacute;ste, detallando cada una de esas notificaciones;<br />\r\nd.8) Practicar&aacute; visita sanitaria al lugar de trabajo e informar&aacute; sobre el tipo de tareas prestadas por el actor, su relaci&oacute;n con las lesiones del mismo y condiciones de salubridad e higiene imperantes;<br />\r\nd.9) Cualquier otro punto que a su juicio sea &uacute;til para la resoluci&oacute;n de la litis.<br />\r\ne) <strong>PERICIAL CONTABLE:</strong><br />\r\nSe deber&aacute; designar perito contador de oficio, para que informe sobre los siguientes puntos:<br />\r\ne.1) Salario diario percibido por el actor, para el c&aacute;lculo de la indemnizaci&oacute;n prevista en la ley 24028;<br />\r\ne.2) Determinar&aacute; el monto de la indemnizaci&oacute;n prevista en la Ley 24028, conforme al grado de incapacidad reclamado y contemplando la depreciaci&oacute;n monetaria producida hasta el momento de la pericia;<br />\r\ne.3) Detallar&aacute; las licencias por enfermedad gozadas por el demandante durante la relaci&oacute;n laboral;<br />\r\ne.4) Al promediar el salario diario correspondiente al a&ntilde;o anterior a la toma de conocimiento, calcular&aacute; la depreciaci&oacute;n monetaria que afect&oacute; las remuneraciones del actor en dicho per&iacute;odo y estimar&aacute; de esa forma el salario diario, compensando el mismo con dicha depreciaci&oacute;n;<br />\r\ne.5) De existir co-demandada citada como aseguradora, informar&aacute; si cubri&oacute; con seguro los riesgos reclamados por el actor y tipo de p&oacute;liza contratada;<br />\r\ne.6) Cualquier otro punto que a su juicio sea &uacute;til para la resoluci&oacute;n de la litis:<br />\r\nf) <strong>INSTRUMENTAL:</strong><br />\r\nSe ofrece la siguiente documentaci&oacute;n:<br />\r\n@000Detallar datos de telegramas@<br />\r\n@000Detallar certificados medicos acompanados@<br />\r\n@000Detallar demas prueba instrumental@<br />\r\ng) <strong>RESERVA DE PRUEBA PERICIAL CALIGRAFICA Y ESCOPOMETRITRICA:</strong><br />\r\nPara el hipot&eacute;tico caso de que la demandada negare la prueba documental y/o firma que se le atribuye, se solicita se haga lugar a la prueba pericial caligr&aacute;fica y escopom&eacute;trica, design&aacute;ndose perito en la firma de estilo, para que previo tomar un cuerpo de escritura suficiente, practique informe sobre la autenticidad de firmas y documentos atribuidos.<br />\r\nh) <strong>INFORMATIVA:</strong><br />\r\nSe deber&aacute; oficiar a:<br />\r\n@000Detallar oficios@<br />\r\ni) <strong>RECONOCIMIENTO DE FIRMA Y CERTIFICADO:</strong><br />\r\nSe deber&aacute; citar a:<br />\r\n@000Se debera citar a reconocer firmas y certificados a ...@<br />\r\nj) <strong>FACULTAD DE DILIGENCIAMIENTO:</strong><br />\r\nSe solicita se autorice a los Dres. @000Personas autorizadas:@, para efectuar durante toda la tramitaci&oacute;n de &eacute;ste expediente, desgloses de documentaci&oacute;n, tr&aacute;mites de c&eacute;dulas, oficios, mandamientos y exhortos.</p>\r\n\r\n<p>5. <strong>DERECHO:</strong><br />\r\nSe funda esta demanda en la Ley 24028 y su decreto reglamentario.</p>\r\n\r\n<p>6. <strong>PETITORIO:</strong><br />\r\nPor todo lo expuesto de V.S. solicito:<br />\r\na) Me tenga por presentado, por parte y por constituido el domicilio legal indicado a m&eacute;rito del poder que adjunto.<br />\r\nb) Corra traslado de la demanda a la accionada.<br />\r\nc) Oportunamente se haga lugar a la acci&oacute;n en la forma ya pedida.</p>\r\n\r\n<p>Proveer de conformidad,</p>\r\n\r\n<p>Ser&aacute; Justicia.</p>\r\n'),(14,'Demanda Por Despido','2014-12-07 23:39:39','2014-12-07 23:39:39','<p><strong><u>INICIA DEMANDA POR DESPIDO</u></strong></p>\r\n\r\n<p>Sr. Juez:</p>\r\n\r\n<p><strong>@004</strong>, constituyendo domicilio legal en la calle @006, a V.S. me presento y digo:</p>\r\n\r\n<p><strong>1. PERSONERIA</strong><br />\r\nQue en nombre y representaci&oacute;n de <strong><u>#@023</u></strong> con domicilio real en la calle @031 de @032, de @000Edad del despedido@ a&ntilde;os de edad, de profesi&oacute;n @105, y de nacionalidad @157, conforme lo justifico con la fotocopia del poder general que adjunto acompa&ntilde;o, debidamente certificada y bajo juramento de ser fiel a su original vigente, vengo en tiempo y forma a promover demanda por despido a <strong>#@041</strong>, domiciliado en @048 de @049#, por la suma de pesos <strong>@101</strong> ($ @018), o lo que en m&aacute;s o en menos resulte en favor de mi conferente con sus intereses y costas, de acuerdo a derecho, actualizado a la fecha de su efectivo pago, con m&aacute;s sus intereses y las costas del juicio.</p>\r\n\r\n<p><strong>2. HECHOS</strong>.<br />\r\n@000Narrar los hechos@</p>\r\n\r\n<p><strong>3. LIQUIDACION</strong><br />\r\n@000Detallar la liquidacion@</p>\r\n\r\n<p><strong>4.</strong> <strong>DERECHO</strong><br />\r\nFundo el derecho de mi parte en lo dispuesto por los arts. @000Arts. en que fundamenta su derecho@.</p>\r\n\r\n<p><strong>5.</strong> <strong>PETITORIO</strong><br />\r\nPor todo lo expuesto a V.S. solicito:<br />\r\na) Me tenga por presentado, parte y constituido el domicilio a m&eacute;rito del poder conferido por mandante, y se corra traslado de la demanda.<br />\r\nb) Se condene al demandado por lo que resulte en m&aacute;s o en menos de la suma que surja de la pericia que en su oportunidad se realice.</p>\r\n\r\n<p>Proveer de conformidad,</p>\r\n\r\n<p>Ser&aacute; Justicia.</p>\r\n'),(15,'Demanda de Desalojo por Falta de Pago','2014-12-07 23:42:16','2014-12-07 23:42:16','<p><strong><u>PROMUEVE DEMANDA DE DESALOJO POR FALTA DE PAGO</u></strong></p>\r\n\r\n<p>Se&ntilde;or Juez:</p>\r\n\r\n<p><strong>@004</strong>, constituyendo domicilio legal en la calle @006, a V.S. respetuosamente digo:</p>\r\n\r\n<p><strong>1. PERSONERIA</strong><br />\r\nQue vengo en nombre y representaci&oacute;n de <strong>#@023</strong> con domicilio real en la calle @031 de @032#, conforme lo justifico con la fotocopia del poder general que adjunto acompa&ntilde;o, debidamente certificada y bajo juramento de ser fiel a su original vigente.</p>\r\n\r\n<p><strong>2. OBJETO</strong><br />\r\nEn tal car&aacute;cter, y habiendo recibido precisas instrucciones de mi poderdante, vengo por el presente a iniciar formal demanda de desalojo por falta de pago, contra <strong>#@041</strong>, subinquilino y/o ocupante de la finca ubicada en la calle @048 de @049# donde se domicilia la demandada, solicitando oportunamente se dicte sentencia que decrete el desalojo de la accionada y de cualquier otro ocupante del inmueble locado bajo apercibimiento de lanzamiento, todo con costas.</p>\r\n\r\n<p><strong>3. HECHOS</strong><br />\r\n@000Narrar los hechos@</p>\r\n\r\n<p><strong>4. PRUEBA<br />\r\na) Documental</strong>:<br />\r\nSe acompa&ntilde;a @000documentos acompanados@.</p>\r\n\r\n<p><strong>b) Informativa</strong>:<br />\r\nSe libre oficio a:<br />\r\n@000Se libren oficios a ...@<br />\r\n<strong>c) Pericial Caligrafica</strong>:<br />\r\nPara el hipot&eacute;tico caso de que la contraria niegue la autenticidad del contrato de locaci&oacute;n o desconozca firmas inusitadas de este, solicito que oportunamente sea citada por el Perito a formar cuerpo de escritura a fin de que el experto determine si es su firma la que luce al pie del contrato.<br />\r\n<strong>d) Confesional</strong>:<br />\r\nSe fije audiencia para que la locataria demandada en autos absuelva posiciones a a tenor del pliego que oportunamente acompa&ntilde;ar&eacute; bajo apercibimiento en caso de incomparecencia de tenerla por confesa en los t&eacute;rminos del art.417 CPCC.</p>\r\n\r\n<p><strong>5. SE NOTIFIQUE</strong><br />\r\nSolicito se notifique la iniciaci&oacute;n de la presente demanda a los garantes de la locataria @000Nombre y Domicilio de los garantes de la locataria@</p>\r\n\r\n<p><strong>6. AUTORIZA</strong><br />\r\nSe autoriza a diligenciar c&eacute;dulas, oficios, tomar vistas del expediente, retirar en pr&eacute;stamo y cualquier otra diligencia que fuera menester para la prosecuci&oacute;n del presente pleito a @000Personas autorizadas:@.</p>\r\n\r\n<p><strong>7. PETITORIO</strong><br />\r\nPor todo lo expuesto a S.S., solicito:<br />\r\na) Me tenga por presentado, por parte y por constituido el domicilio legal indicado a m&eacute;rito del poder que adjunto.<br />\r\nb) Se corra traslado de la demanda interpuesta por el t&eacute;rmino de ley.<br />\r\nc) Oportunamente se dicte sentencia que decrete el desalojo del accionado y de cualquier otro ocupante del bien locado, con expresa imposici&oacute;n de costas.</p>\r\n\r\n<p>Proveer de conformidad,</p>\r\n\r\n<p>Ser&aacute; Justicia.</p>\r\n'),(16,'Demanda Por Prescripción','2014-12-07 23:45:16','2014-12-07 23:45:16','<p><strong><u>DEMANDA POR POSESION VEINTEA&Ntilde;AL</u></strong></p>\r\n\r\n<p>Se&ntilde;or Juez:</p>\r\n\r\n<p><strong>@004</strong>, constituyendo domicilio legal en la calle @006, a V.S. respetuosamente digo:</p>\r\n\r\n<p><strong>1. PERSONERIA</strong><br />\r\nQue vengo en nombre y representaci&oacute;n de <strong>#@023</strong> con domicilio real en la calle @031 de @032#, conforme lo justifico con la fotocopia del poder general que adjunto acompa&ntilde;o, debidamente certificada y bajo juramento de ser fiel a su original vigente.</p>\r\n\r\n<p><strong>2. OBJETO</strong><br />\r\nEn el car&aacute;cter invocado vengo a iniciar acci&oacute;n por prescripci&oacute;n adquisitiva de dominio de @000prescripcion adquisitiva de ...@ que adelante se&ntilde;alar&eacute; contra <strong>#@040</strong>, con domicilio en la calle @048, @049# con el objeto de @000con el objeto de ...@.<br />\r\nEn su oportunidad solicito se dicte sentencia haciendo lugar a la demanda, ordenando cancelar el dominio del demandado, inscribiendo a mi nombre el nuevo dominio y aplicando las costas al accionado. Todo ello en raz&oacute;n de los siguientes hechos y derecho que paso a exponer.</p>\r\n\r\n<p><strong>3. HECHOS</strong><br />\r\n@000Narrar los hechos@</p>\r\n\r\n<p><strong>4. PRUEBA<br />\r\na)</strong> <strong>CONFESIONAL Y RECONOCIMIENTO</strong>: Se citar&aacute; al demandado a absolver posiciones a tenor del pliego de posiciones que se acompa&ntilde;ar&aacute; bajo apercibimiento de ley, y a reconocer documentaci&oacute;n<br />\r\n<strong>b) DOCUMENTAL</strong>: @000Detalle Prueba documental@.<br />\r\n<strong>c) INFORMATIVA</strong>: Se libraran los siguientes oficios:<br />\r\nSe libren oficios a los siguientes: @000Se libren oficios a ...@<br />\r\n<strong>d) INSPECCION OCULAR</strong>: Se efectuar&aacute; en el domicilio a usucapir y por intermedio del Actuario.<br />\r\n<strong>e) TESTIMONIAL</strong>: Se ofrece la declaraci&oacute;n de las siguientes testigos:<br />\r\n#@066, @111, @112, con domicilio en @085#</p>\r\n\r\n<p><strong>5. COMPETENCIA</strong><br />\r\nV.S. es competente para entender en esta acci&oacute;n en m&eacute;rito a lo dispuesto por el art. @000art. en que fundamenta la competencia@.</p>\r\n\r\n<p><strong>6. DERECHO</strong><br />\r\nFundo la petici&oacute;n en el derecho que me otorgan los arts. 679 y ccdtes. del CPCC y arts. 4015 y cctes del C&oacute;digo Civil.</p>\r\n\r\n<p><strong>7.</strong> <strong>PETITORIO</strong><br />\r\nPor todo lo expuesto a V.S. solicito:<br />\r\na) Me tenga por presentado, por parte y por constituido el domicilio legal indicado a m&eacute;rito del poder que adjunto.<br />\r\nb) Agregue la documentaci&oacute;n acompa&ntilde;ada y por ofrecida la prueba para la etapa procesal oportuna.<br />\r\nc) De traslado de la demanda en la forma de estilo y bajo apercibimiento de ley.<br />\r\nd) En su oportunidad dicte sentencia haciendo lugar a la demanda en todas sus partes, y en su consecuencia declarando adquirido el bien inmueble, libr&aacute;ndose oficio al Registro de la Propiedad y cancelando el anterior dominio, con costas.</p>\r\n\r\n<p>Proveer de conformidad,</p>\r\n\r\n<p>Ser&aacute; Justicia.</p>\r\n'),(17,'Demanda de Quiebra','2014-12-07 23:54:58','2014-12-07 23:54:58','<p><strong><u>PROMUEVE PEDIDO DE QUIEBRA</u></strong></p>\r\n\r\n<p>Se&ntilde;or Juez:<br />\r\n<strong>@004</strong>, con domicilio legal en la calle @006, a V.S. respetuosamente digo:</p>\r\n\r\n<p><strong>1</strong>. <strong>PERSONERIA</strong><br />\r\nQue en nombre y representaci&oacute;n de <strong>#@023</strong> con domicilio en @031, de @032# conforme lo justifico con la fotocopia del poder general judicial que adjunto acompa&ntilde;o, debidamente certificada y bajo juramento de ser fiel a su original vigente</p>\r\n\r\n<p><strong>2. OBJETO</strong><br />\r\nQue vengo en tiempo y forma a solicitar de V.S. que previo cumplimiento de los recaudos de ley, se sirva decretar la quiebra de <strong>#@040</strong> con domicilio en la calle @048, de la localidad de @049#, con costas.</p>\r\n\r\n<p><strong>3. HECHOS</strong><br />\r\nEl cr&eacute;dito proviene de @000Credito proviene de...@<br />\r\nA efectos de acreditar el car&aacute;cter de comerciante de la deudora solicito el libramiento de oficio al Registro P&uacute;blico de Comercio para que informe si la misma se encuentra inscripta en los registros a su cargo.<br />\r\n@000Hechos@</p>\r\n\r\n<p><strong>4. PRUEBA </strong><br />\r\nA fin de probar los hechos expuestos ofrezco la siguiente prueba:<br />\r\n<strong>DOCUMENTAL:</strong> Se acompa&ntilde;a la siguiente prueba documental: @000prueba documental acompanada@<br />\r\n@000Demas prueba que no sea documental ofrecida@</p>\r\n\r\n<p><strong>5. COMPETENCIA</strong><br />\r\nV.S. es competente para entender en esta acci&oacute;n en m&eacute;rito a lo dispuesto por el art. @000art. en que fundamenta la competencia@.</p>\r\n\r\n<p><strong>6. DERECHO</strong><br />\r\nFundo el derecho que asiste a mi mandante en la Ley 19551.</p>\r\n\r\n<p><strong>7.</strong> <strong>PETITORIO</strong><br />\r\nPor todo lo expuesto a V.S. solicito:<br />\r\na) Me tenga por presentado, por parte y por constituido el domicilio legal indicado.<br />\r\nb) Se agregue la documentaci&oacute;n adjunta reserv&aacute;ndola en Secretaria con constancia en autos de las respectivas fotocopias agregadas.<br />\r\nc) Se libre el certificado que establece el D.L.3003/56.<br />\r\nd) Se libre el oficio pedido en el principal.<br />\r\ne) Oportunamente se cite a la deudora comparezca a dar explicaciones bajo apercibimiento de ley. Con costas.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Proveer de conformidad,</p>\r\n\r\n<p>Ser&aacute; Justicia.&nbsp;</p>\r\n'),(18,'Se Decrete la Quiebra','2014-12-07 23:56:26','2014-12-07 23:56:26','<p><strong><u>SE DECRETE LA QUIEBRA</u></strong></p>\r\n\r\n<p>Se&ntilde;or Juez:</p>\r\n\r\n<p><strong>@004</strong>, en mi car&aacute;cter de Letrado @005 de la parte #@025#, con domicilio legal constituido en la calle @006, en los autos caratulados: <strong>&quot;@002&quot;</strong>, (Expte. N&ordm; @016), a V.S. digo:</p>\r\n\r\n<p>Que atento al estado de autos, no habiendo la deudora comparecido a dar explicaciones sobre el estado de sus negocios pese a encontrarse debidamente notificada para ello, y haciendo efectivo el apercibimiento prevenido, vengo a solicitar se sirva V.S. decretar su quiebra conforme lo pedido en el escrito de inicio.</p>\r\n\r\n<p>Proveer de conformidad,</p>\r\n\r\n<p>Ser&aacute; Justicia.</p>\r\n\r\n<p>J:@009 / S:@010</p>\r\n');
/*!40000 ALTER TABLE `modelos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modelos_codigos`
--

DROP TABLE IF EXISTS `modelos_codigos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modelos_codigos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modelos_codigos`
--

LOCK TABLES `modelos_codigos` WRITE;
/*!40000 ALTER TABLE `modelos_codigos` DISABLE KEYS */;
INSERT INTO `modelos_codigos` VALUES (1,'@004','Abogado del Estudio que interviene en el proceso / Proceso / Caracter de Interv.','0000-00-00 00:00:00','0000-00-00 00:00:00'),(2,'@002','Caratula','0000-00-00 00:00:00','0000-00-00 00:00:00'),(3,'#@023','Cliente (Nombre y Apellido en mayúsculas)','0000-00-00 00:00:00','0000-00-00 00:00:00'),(4,'@157','Cliente / Nacionalidad','0000-00-00 00:00:00','0000-00-00 00:00:00'),(5,'@031','Cliente / Dirección','0000-00-00 00:00:00','0000-00-00 00:00:00'),(6,'@032#','Clientes / Ciudad','0000-00-00 00:00:00','0000-00-00 00:00:00'),(7,'@005','Caracter de Intervensión','0000-00-00 00:00:00','0000-00-00 00:00:00'),(8,'#@025#','Clientes / Carácter de Parte','0000-00-00 00:00:00','0000-00-00 00:00:00'),(9,'@006','Proceso / Domicilio Constituído','0000-00-00 00:00:00','0000-00-00 00:00:00'),(10,'@016','Radicación / Nro. Exp. en la instacia actual','0000-00-00 00:00:00','0000-00-00 00:00:00'),(11,'@020','Movimiento de Procuración - Textos / Contenido del Texto','0000-00-00 00:00:00','0000-00-00 00:00:00'),(12,'#@066','Testimonial / Testigo','0000-00-00 00:00:00','0000-00-00 00:00:00'),(13,'@111','Testimonial / Profesión','0000-00-00 00:00:00','0000-00-00 00:00:00'),(14,'@067#','Testimonial / Domiciio','0000-00-00 00:00:00','0000-00-00 00:00:00'),(15,'#@076','Informativa / Informante','0000-00-00 00:00:00','0000-00-00 00:00:00'),(16,'@078','Informativa / Materia','0000-00-00 00:00:00','0000-00-00 00:00:00'),(17,'@083#','Informativa / Observaciones','0000-00-00 00:00:00','0000-00-00 00:00:00'),(18,'@000Puntos de Pericia Contable@','Puntos de Pericia Contable','0000-00-00 00:00:00','0000-00-00 00:00:00'),(19,'@000Detalle Pericial Caligrafica@','Detalle Pericial Caligráfica','0000-00-00 00:00:00','0000-00-00 00:00:00'),(20,'J:@009','Juzgado','0000-00-00 00:00:00','0000-00-00 00:00:00'),(21,'S:@010','Secretaría','0000-00-00 00:00:00','0000-00-00 00:00:00'),(22,'@032','Clientes / Ciudad','0000-00-00 00:00:00','0000-00-00 00:00:00'),(23,'@025','Clientes / Carácter de parte','0000-00-00 00:00:00','0000-00-00 00:00:00'),(24,'#@040','Oponentes y Terceros / Nombre y Apellido (en Mayúsculas)','0000-00-00 00:00:00','0000-00-00 00:00:00'),(25,'@048','Oponentes y Terceros (Dirección)','0000-00-00 00:00:00','0000-00-00 00:00:00'),(26,'@049#','Oponentes y Terceros (Ciudad)','0000-00-00 00:00:00','0000-00-00 00:00:00'),(27,'@018','Proceso / Capital Reclamado','0000-00-00 00:00:00','0000-00-00 00:00:00'),(28,'@101','Proceso / Capital Reclamado en Letras','0000-00-00 00:00:00','0000-00-00 00:00:00'),(29,'@112','Testimonial / Documento de Identidad','0000-00-00 00:00:00','0000-00-00 00:00:00'),(30,'@085#','Pericial / Domicilio','0000-00-00 00:00:00','0000-00-00 00:00:00'),(31,'#@041','Oponentes y Terceros / Nombre y Apellido','0000-00-00 00:00:00','0000-00-00 00:00:00'),(32,'@105','Cliente / Profesión','0000-00-00 00:00:00','0000-00-00 00:00:00'),(33,'@029','Cliente / Fecha de Nacimiento','0000-00-00 00:00:00','0000-00-00 00:00:00'),(34,'@030#','Cliente / Documento de Identidad','0000-00-00 00:00:00','0000-00-00 00:00:00'),(35,'@042','Oponentes y Terceros / Caracter de Parte','0000-00-00 00:00:00','0000-00-00 00:00:00'),(36,'@047','Oponentes y Terceros / DNI','0000-00-00 00:00:00','0000-00-00 00:00:00'),(37,'@030','Cliente / DNI','0000-00-00 00:00:00','0000-00-00 00:00:00'),(40,'@000Hechos@','Hechos','0000-00-00 00:00:00','0000-00-00 00:00:00'),(41,'@000Fundo el derecho en los arts ...@','Fundo el derecho en los arts ...','0000-00-00 00:00:00','0000-00-00 00:00:00'),(42,'@000Detalle la prueba documental@','Detalle la prueba documental','0000-00-00 00:00:00','0000-00-00 00:00:00'),(43,'@000Colocar segun corresponda|demanda Sumaria|demanda Ordinaria@','Colocar según corresponda|demanda Sumaria|demanda Ordinaria','0000-00-00 00:00:00','0000-00-00 00:00:00'),(44,'@000Comenzar pto. 4 despues de negativa general@','Comenzar pto. 4 después de negativa general','0000-00-00 00:00:00','0000-00-00 00:00:00'),(45,'@000Detallar los danos@','Detallar los daños','0000-00-00 00:00:00','0000-00-00 00:00:00'),(46,'@000Lapso por el cual fue privado del uso@','Lapso por el cual fue privado del uso','0000-00-00 00:00:00','0000-00-00 00:00:00'),(47,'@000Monto en Nro y letras por la privacion de uso@','Monto en Nº y letras por la privación de uso','0000-00-00 00:00:00','0000-00-00 00:00:00'),(48,'@000Arts. en los que fundamenta la accion@','Arts. en los que fundamenta la acción','0000-00-00 00:00:00','0000-00-00 00:00:00'),(49,'@000Detalle Prueba documental@','Detalle Prueba documental','0000-00-00 00:00:00','0000-00-00 00:00:00'),(50,'@000Detalle Prueba pericial@','Detalle Prueba pericial','0000-00-00 00:00:00','0000-00-00 00:00:00'),(51,'@000Se libren oficios a ...@','Se libren oficios a ...','0000-00-00 00:00:00','0000-00-00 00:00:00'),(52,'@000Nombre de los padres del menor@','Nombre de los padres del menor','0000-00-00 00:00:00','0000-00-00 00:00:00'),(53,'@000Fecha de nacimiento del menor@','Fecha de nacimiento del menor','0000-00-00 00:00:00','0000-00-00 00:00:00'),(54,'@000Lugar de nacimiento@','Lugar de nacimiento','0000-00-00 00:00:00','0000-00-00 00:00:00'),(55,'@000Fecha desde la cual se tiene al menor bajo guarda@','Fecha desde la cual se tiene al menor bajo guarda','0000-00-00 00:00:00','0000-00-00 00:00:00'),(56,'@000Anos de guarda@','Años de guarda','0000-00-00 00:00:00','0000-00-00 00:00:00'),(57,'@000Fecha de casamiento@','Fecha de casamiento','0000-00-00 00:00:00','0000-00-00 00:00:00'),(58,'@000Entrada mensual de los conyuges@','Entrada mensual de los cónyuges','0000-00-00 00:00:00','0000-00-00 00:00:00'),(59,'@000Nombre de el o los hijos@','Nombre de el o los hijos','0000-00-00 00:00:00','0000-00-00 00:00:00'),(60,'@000Monto en letras de cuota provisoria de alimentos@','Monto en letras de cuota provisoria de alimentos','0000-00-00 00:00:00','0000-00-00 00:00:00'),(61,'@000Monto en numeros@','Monto en números','0000-00-00 00:00:00','0000-00-00 00:00:00'),(62,'@000Detallar medidas cautelares que se solicitan@','Detallar medidas cautelares que se solicitan','0000-00-00 00:00:00','0000-00-00 00:00:00'),(63,'@000Prueba documental: partida matrim. y nacim, y ...@','Prueba documental: partida matrim. y nacim, y ...','0000-00-00 00:00:00','0000-00-00 00:00:00'),(65,'@000Elegir entre:|hijo legitimo|hijos legitimos@','Elegir entre:|hijo legítimo|hijos legítimos','0000-00-00 00:00:00','0000-00-00 00:00:00'),(66,'@000Indique fs. del fallo@','Indique fs. del fallo','0000-00-00 00:00:00','0000-00-00 00:00:00'),(67,'@000Fundar en derecho@','Fundar en derecho','0000-00-00 00:00:00','0000-00-00 00:00:00'),(68,'@000Prueba documental@','Prueba documental','0000-00-00 00:00:00','0000-00-00 00:00:00'),(69,'@000Personas autorizadas:@','Personas autorizadas','0000-00-00 00:00:00','0000-00-00 00:00:00'),(70,'@027','Estado Civil','0000-00-00 00:00:00','0000-00-00 00:00:00'),(71,'@000Narrar hechos y contrato de trabajo@','Narrar hechos y contrato de trabajo','0000-00-00 00:00:00','0000-00-00 00:00:00'),(72,'@000Detallar datos de telegramas@','Detallar datos de telegramas','0000-00-00 00:00:00','0000-00-00 00:00:00'),(73,'@000Detallar certificados medicos acompanados@','Detallar certificados médicos acompañados','0000-00-00 00:00:00','0000-00-00 00:00:00'),(74,'@000Detallar demas prueba instrumental@','Detallar demás prueba instrumental','0000-00-00 00:00:00','0000-00-00 00:00:00'),(75,'@000Detallar oficios@','Detallar oficios','0000-00-00 00:00:00','0000-00-00 00:00:00'),(76,'@000Se debera citar a reconocer firmas y certificados a ...@','Se deberá citar a reconocer firmas y certificados a ...','0000-00-00 00:00:00','0000-00-00 00:00:00'),(77,'@000Edad del despedido@','Edad del despedido','0000-00-00 00:00:00','0000-00-00 00:00:00'),(78,'@000Narrar los hechos@','Narrar los hechos','0000-00-00 00:00:00','0000-00-00 00:00:00'),(79,'@000Detallar la liquidacion@','Detallar la liquidación','0000-00-00 00:00:00','0000-00-00 00:00:00'),(80,'@000Arts. en que fundamenta su derecho@','000Arts. en que fundamenta su derecho','0000-00-00 00:00:00','0000-00-00 00:00:00'),(81,'@000documentos acompanados@','Documentos acompañados','0000-00-00 00:00:00','0000-00-00 00:00:00'),(82,'@000Nombre y Domicilio de los garantes de la locataria@','Nombre y Domicilio de los garantes de la locataria','0000-00-00 00:00:00','0000-00-00 00:00:00'),(83,'@000prescripcion adquisitiva de ...@','Prescripción adquisitiva de ...','0000-00-00 00:00:00','0000-00-00 00:00:00'),(84,'@000con el objeto de ...@','Con el objeto de ...','0000-00-00 00:00:00','0000-00-00 00:00:00'),(85,'@000art. en que fundamenta la competencia@.','Art. en que fundamenta la competencia','0000-00-00 00:00:00','0000-00-00 00:00:00'),(86,'@000Credito proviene de...@','Credito proviene de...','0000-00-00 00:00:00','0000-00-00 00:00:00'),(87,'@000prueba documental acompanada@','Prueba documental acompañada','0000-00-00 00:00:00','0000-00-00 00:00:00'),(88,'@000Demas prueba que no sea documental ofrecida@','Demás prueba que no sea documental ofrecida','0000-00-00 00:00:00','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `modelos_codigos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modelos_codigos_relacionados`
--

DROP TABLE IF EXISTS `modelos_codigos_relacionados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modelos_codigos_relacionados` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `modelos_codigo_id` int(10) unsigned NOT NULL,
  `modelo_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `modelos_codigos_relacionados_modelo_id_foreign` (`modelo_id`),
  KEY `modelos_codigos_relacionados_modelos_codigo_id_foreign` (`modelos_codigo_id`),
  CONSTRAINT `modelos_codigos_relacionados_modelo_id_foreign` FOREIGN KEY (`modelo_id`) REFERENCES `modelos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `modelos_codigos_relacionados_modelos_codigo_id_foreign` FOREIGN KEY (`modelos_codigo_id`) REFERENCES `modelos_codigos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=223 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modelos_codigos_relacionados`
--

LOCK TABLES `modelos_codigos_relacionados` WRITE;
/*!40000 ALTER TABLE `modelos_codigos_relacionados` DISABLE KEYS */;
INSERT INTO `modelos_codigos_relacionados` VALUES (1,1,1,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(2,9,1,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(3,3,1,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(4,5,1,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(5,6,1,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(6,24,1,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(7,25,1,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(8,26,1,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(9,40,1,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(10,41,1,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(11,42,1,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(12,43,1,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(13,1,2,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(14,9,2,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(15,10,2,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(16,2,2,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(17,3,2,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(18,5,2,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(19,22,2,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(20,44,2,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(21,20,2,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(22,21,2,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(23,1,4,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(24,9,4,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(25,3,4,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(26,5,4,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(27,6,4,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(28,24,4,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(29,25,4,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(30,26,4,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(31,27,4,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(32,28,4,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(33,78,4,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(34,45,4,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(35,46,4,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(36,47,4,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(37,48,4,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(38,42,4,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(39,49,4,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(40,50,4,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(41,51,4,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(50,1,6,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(51,7,6,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(52,23,6,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(53,9,6,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(54,2,6,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(55,10,6,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(56,20,6,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(57,21,6,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(58,1,7,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(59,9,7,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(60,3,7,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(61,5,7,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(62,6,7,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(63,31,7,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(64,52,7,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(65,53,7,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(66,54,7,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(67,55,7,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(68,56,7,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(69,57,7,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(70,58,7,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(71,1,8,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(72,9,8,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(73,3,8,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(74,5,8,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(75,6,8,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(76,59,8,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(77,24,8,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(78,25,8,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(79,26,8,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(80,78,8,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(81,60,8,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(82,61,8,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(83,62,8,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(84,63,8,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(85,12,8,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(86,13,8,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(87,29,8,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(88,30,8,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(89,51,8,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(90,65,8,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(91,1,10,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(92,7,10,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(93,23,10,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(94,9,10,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(95,2,10,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(96,10,10,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(97,20,10,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(98,21,10,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(99,3,11,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(100,1,11,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(101,9,11,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(102,2,11,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(103,10,11,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(104,66,11,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(105,20,11,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(106,21,11,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(107,1,12,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(108,7,12,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(109,8,12,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(110,9,12,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(111,10,12,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(112,3,12,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(113,4,12,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(114,37,12,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(115,5,12,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(116,6,12,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(117,11,12,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(118,67,12,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(119,68,12,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(120,12,12,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(121,13,12,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(122,14,12,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(123,15,12,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(124,16,12,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(125,17,12,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(126,18,12,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(127,19,12,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(128,69,12,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(129,20,12,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(130,21,12,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(131,1,13,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(132,9,13,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(133,3,13,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(134,5,13,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(135,22,13,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(136,4,13,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(137,33,13,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(138,32,13,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(139,70,13,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(140,34,13,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(141,24,13,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(142,25,13,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(143,26,13,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(144,71,13,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(145,35,13,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(146,12,13,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(147,14,13,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(148,72,13,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(149,73,13,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(150,74,13,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(151,75,13,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(152,76,13,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(153,69,13,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(154,1,14,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(155,9,14,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(156,3,14,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(157,5,14,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(158,22,14,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(159,77,14,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(160,32,14,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(161,4,14,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(162,31,14,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(163,25,14,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(164,26,14,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(165,28,14,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(166,27,14,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(167,78,14,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(168,79,14,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(169,80,14,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(170,1,15,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(171,9,15,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(172,3,15,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(173,5,15,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(174,6,15,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(175,31,15,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(176,25,15,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(177,26,15,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(178,78,15,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(179,81,15,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(180,51,15,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(181,82,15,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(182,69,15,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(183,1,16,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(184,9,16,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(185,3,16,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(186,5,16,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(187,6,16,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(188,83,16,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(189,24,16,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(190,25,16,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(191,26,16,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(192,84,16,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(193,78,16,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(194,49,16,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(195,51,16,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(196,12,16,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(197,13,16,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(198,29,16,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(199,30,16,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(200,85,16,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(201,1,17,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(202,9,17,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(203,3,17,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(204,5,17,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(205,6,17,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(206,24,17,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(207,25,17,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(208,26,17,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(209,86,17,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(210,40,17,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(211,87,17,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(212,88,17,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(213,85,17,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(214,1,18,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(215,7,18,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(216,8,18,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(217,9,18,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(218,2,18,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(219,10,18,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(220,20,18,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(221,21,18,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(222,2,12,'0000-00-00 00:00:00','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `modelos_codigos_relacionados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modelos_procesos`
--

DROP TABLE IF EXISTS `modelos_procesos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modelos_procesos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modelos_procesos`
--

LOCK TABLES `modelos_procesos` WRITE;
/*!40000 ALTER TABLE `modelos_procesos` DISABLE KEYS */;
INSERT INTO `modelos_procesos` VALUES (1,'Civil Común','0000-00-00 00:00:00','0000-00-00 00:00:00'),(2,'Comercial Común','0000-00-00 00:00:00','0000-00-00 00:00:00'),(3,'Sucesiones','0000-00-00 00:00:00','0000-00-00 00:00:00'),(4,'Familia','0000-00-00 00:00:00','0000-00-00 00:00:00'),(5,'Penal','0000-00-00 00:00:00','0000-00-00 00:00:00'),(6,'Laboral','0000-00-00 00:00:00','0000-00-00 00:00:00'),(7,'Documento y Locaciones','0000-00-00 00:00:00','0000-00-00 00:00:00'),(8,'Cobro y Apremio','0000-00-00 00:00:00','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `modelos_procesos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modelos_procesos_relacionados`
--

DROP TABLE IF EXISTS `modelos_procesos_relacionados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modelos_procesos_relacionados` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `modelos_proceso_id` int(10) unsigned NOT NULL,
  `modelo_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `modelos_procesos_relacionados_modelo_id_foreign` (`modelo_id`),
  KEY `modelos_procesos_relacionados_modelos_proceso_id_foreign` (`modelos_proceso_id`),
  CONSTRAINT `modelos_procesos_relacionados_modelo_id_foreign` FOREIGN KEY (`modelo_id`) REFERENCES `modelos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `modelos_procesos_relacionados_modelos_proceso_id_foreign` FOREIGN KEY (`modelos_proceso_id`) REFERENCES `modelos_procesos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modelos_procesos_relacionados`
--

LOCK TABLES `modelos_procesos_relacionados` WRITE;
/*!40000 ALTER TABLE `modelos_procesos_relacionados` DISABLE KEYS */;
INSERT INTO `modelos_procesos_relacionados` VALUES (19,1,1,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(20,1,2,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(21,2,1,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(22,2,4,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(23,2,2,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(24,3,6,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(25,4,7,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(26,4,8,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(27,5,1,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(28,5,10,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(29,5,11,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(30,6,12,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(31,6,13,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(32,6,14,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(33,7,15,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(34,7,16,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(35,8,17,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(36,8,18,'0000-00-00 00:00:00','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `modelos_procesos_relacionados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pagos`
--

DROP TABLE IF EXISTS `pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pagos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `expediente_id` int(10) unsigned DEFAULT NULL,
  `tipo_pago` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tipo_operacion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `monto` decimal(11,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `pagos_expediente_id_foreign` (`expediente_id`),
  CONSTRAINT `pagos_expediente_id_foreign` FOREIGN KEY (`expediente_id`) REFERENCES `expedientes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pagos`
--

LOCK TABLES `pagos` WRITE;
/*!40000 ALTER TABLE `pagos` DISABLE KEYS */;
INSERT INTO `pagos` VALUES (1,NULL,'Egreso','Luz',450.00,'2014-12-09 23:42:45','2014-12-09 23:42:45'),(2,1,'Ingreso','Fotocopias',100.00,'2014-12-09 23:43:31','2014-12-09 23:43:31'),(3,NULL,'Egreso','Teléfono',20.00,'2014-12-09 23:44:53','2014-12-09 23:44:53'),(4,2,'Ingreso','Oficios',750.00,'2014-12-09 23:47:17','2014-12-09 23:47:17');
/*!40000 ALTER TABLE `pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reminders`
--

DROP TABLE IF EXISTS `password_reminders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reminders` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `password_reminders_email_index` (`email`),
  KEY `password_reminders_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reminders`
--

LOCK TABLES `password_reminders` WRITE;
/*!40000 ALTER TABLE `password_reminders` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reminders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `apellido` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dni` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `fecha_nacimiento` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `user` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `perfil` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `domicilio` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_temp` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `codigo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `titular_id` int(10) unsigned DEFAULT NULL,
  `parentesco` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `legajo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `estado_civil` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `localidad` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sexo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `telefono` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `celular` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `profesion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fecha_ingreso` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `discapacidad` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'admin','','11111111','','admin','$2y$10$ZXNB9wlnlFqdSWHmditNb.Vh1F9CjNEQ1eMsS2Ly3aUQZsKADmW3O','Administrador','estudio.aboga2@gmail.com','','','','kQmPmifSOMPYJrNXuZaJKArylWvEmMdrE6FCvschNVKq8iclxYPhynDfMHAC','Activo','0000-00-00 00:00:00','2014-11-25 04:59:27',NULL,'','','','','','','','','',NULL),(2,'Ariel','Matos','25455455','','ariel','','Abogado Jr','ariel@abogados.com','jskaskajskajkajsk','','',NULL,'Activo','2014-11-25 01:15:15','2014-11-25 01:40:18',NULL,'Titular','','','','','','','','',NULL);
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-12-12 11:29:12
